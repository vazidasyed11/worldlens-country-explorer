import { useMemo, useState } from "react";
import { getCountries } from "../api/countries";
import useFetch from "../hooks/useFetch";
import SearchBar from "../components/SearchBar";
import RegionFilter from "../components/RegionFilter";
import CountryGrid from "../components/CountryGrid";
import Loading from "../components/Loading";
import ErrorState from "../components/ErrorState";
import { FALLBACK_COUNTRIES } from "../api/fallbackCountries";

export default function HomePage() {
  const [search, setSearch] = useState("");
  const [region, setRegion] = useState("");
  const { data: countries, loading, error } = useFetch(getCountries, []);
  const usingOfflineData = countries === FALLBACK_COUNTRIES;

  const filteredCountries = useMemo(() => {
    if (!countries) return [];
    const query = search.trim().toLowerCase();

    return countries
      .filter((country) => !region || country.region === region)
      .filter((country) => {
        if (!query) return true;
        return country.name?.common?.toLowerCase().includes(query)
          || country.name?.official?.toLowerCase().includes(query);
      })
      .sort((a, b) => a.name.common.localeCompare(b.name.common));
  }, [countries, search, region]);

  return (
    <>
      <section className="hero">
        <div>
          <p className="eyebrow">Interactive geography</p>
          <h1>Explore the world, one country at a time.</h1>
          <p className="hero-copy">
            Search countries, filter by region, and follow borders to discover what is next.
          </p>
        </div>
        <div className="hero-globe" aria-hidden="true">◎</div>
      </section>

      <section className="toolbar" aria-label="Country filters">
        <SearchBar value={search} onChange={setSearch} />
        <RegionFilter value={region} onChange={setRegion} />
      </section>

      {loading && <Loading />}
      {error && <ErrorState message={error.message} />}

      {!loading && !error && (
        <>
          {usingOfflineData && (
            <div className="offline-note">Live API is unavailable, so WorldLens is showing its built-in offline sample data. The app will use live country data automatically when the API is reachable.</div>
          )}

          <div className="results-row">
            <h2>Countries <span>{filteredCountries.length}</span></h2>
            {(search || region) && (
              <button className="reset-button" onClick={() => { setSearch(""); setRegion(""); }}>
                Reset filters
              </button>
            )}
          </div>

          {filteredCountries.length ? (
            <CountryGrid countries={filteredCountries} />
          ) : (
            <div className="status-card">
              <div className="status-icon">⌕</div>
              <strong>No countries found</strong>
              <span>Try another search term or region.</span>
            </div>
          )}
        </>
      )}
    </>
  );
}