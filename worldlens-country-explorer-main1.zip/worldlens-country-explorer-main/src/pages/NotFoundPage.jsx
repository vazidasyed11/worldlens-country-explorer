import { Link } from "react-router-dom";

export default function NotFoundPage() {
  return (
    <div className="not-found status-card">
      <div className="status-icon">404</div>
      <strong>Page not found</strong>
      <span>The country or page you requested does not exist.</span>
      <Link className="primary-button" to="/">Return home</Link>
    </div>
  );
}