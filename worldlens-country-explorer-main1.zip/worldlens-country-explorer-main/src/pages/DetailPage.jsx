import { Link, useParams } from "react-router-dom";
import { getCountry } from "../api/countries";
import useFetch from "../hooks/useFetch";
import useFetchCountries from "../hooks/useFetchCountries";
import BorderLinks from "../components/BorderLinks";
import Loading from "../components/Loading";
import ErrorState from "../components/ErrorState";

const formatNumber = (value) => new Intl.NumberFormat().format(value ?? 0);
const objectValues = (value) => value ? Object.values(value) : [];

export default function DetailPage() {
  const { code } = useParams();
  const { data: country, loading, error } = useFetch(
    (signal) => getCountry(code, signal),
    [code]
  );
  const { data: allCountries } = useFetchCountries();

  if (loading) return <Loading message="Loading country..." />;
  if (error || !country) return <ErrorState message={error?.message || "Country not found."} />;

  const languages = objectValues(country.languages);
  const currencies = objectValues(country.currencies).map((item) => item.name).filter(Boolean);
  const countryName = country.name?.common || "Country";

  return (
    <article className="detail-page">
      <Link className="back-link" to="/">← Back to all countries</Link>

      <div className="detail-layout">
        <div className="detail-flag">
          <img src={country.flags?.svg || country.flags?.png} alt={`${countryName} flag`} />
        </div>

        <div className="detail-content">
          <p className="eyebrow">{country.region} · {country.subregion || "World"}</p>
          <h1>{countryName}</h1>
          <p className="official-name">{country.name?.official}</p>

          <div className="facts-grid">
            <Fact label="Capital" value={country.capital?.join(", ") || "—"} />
            <Fact label="Population" value={formatNumber(country.population)} />
            <Fact label="Area" value={`${formatNumber(country.area)} km²`} />
            <Fact label="Region" value={country.region || "—"} />
            <Fact label="Languages" value={languages.join(", ") || "—"} />
            <Fact label="Currencies" value={currencies.join(", ") || "—"} />
            <Fact label="Top-level domain" value={country.tld?.join(", ") || "—"} />
            <Fact label="Calling code" value={country.idd?.root ? `${country.idd.root}${country.idd.suffixes?.[0] || ""}` : "—"} />
          </div>

          <section className="detail-section">
            <h2>Border countries</h2>
            <BorderLinks borders={country.borders} countries={allCountries || []} />
          </section>

          {country.maps?.googleMaps && (
            <a className="map-link" href={country.maps.googleMaps} target="_blank" rel="noreferrer">
              Open in Google Maps ↗
            </a>
          )}
        </div>
      </div>
    </article>
  );
}

function Fact({ label, value }) {
  return (
    <div className="fact">
      <dt>{label}</dt>
      <dd>{value}</dd>
    </div>
  );
}