import { FALLBACK_COUNTRIES } from "./fallbackCountries";

const API = "https://restcountries.com/v3.1";
const listFields = ["name", "cca3", "capital", "flags", "region", "population", "languages", "currencies", "borders"].join(",");
const detailFields = ["name", "cca3", "capital", "flags", "region", "subregion", "population", "languages", "currencies", "borders", "area", "tld", "idd", "maps"].join(",");

async function requestJson(url, signal) {
  const response = await fetch(url, { signal, headers: { Accept: "application/json" } });
  if (!response.ok) throw new Error(`Request failed (${response.status})`);
  return response.json();
}

export async function getCountries(signal) {
  try {
    // Keep the live REST Countries API as the primary source.
    return await requestJson(`${API}/all?fields=${listFields}`, signal);
  } catch (error) {
    if (error?.name === "AbortError") throw error;
    console.warn("REST Countries API unavailable; using offline demo data.", error);
    return FALLBACK_COUNTRIES;
  }
}

export async function getCountry(code, signal) {
  try {
    const data = await requestJson(`${API}/alpha/${encodeURIComponent(code)}?fields=${detailFields}`, signal);
    return Array.isArray(data) ? data[0] : data;
  } catch (error) {
    if (error?.name === "AbortError") throw error;
    const fallback = FALLBACK_COUNTRIES.find((country) => country.cca3 === code?.toUpperCase());
    if (fallback) return fallback;
    throw new Error("Country not found.");
  }
}
