import { getCountries } from "../api/countries";
import useFetch from "./useFetch";

export default function useFetchCountries() {
  return useFetch(getCountries, []);
}