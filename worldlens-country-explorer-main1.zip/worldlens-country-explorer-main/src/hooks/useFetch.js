import { useEffect, useState } from "react";

/**
 * Generic fetch hook. A fresh AbortController is created per request
 * and aborted on cleanup, preventing state updates from stale requests.
 */
export default function useFetch(fetcher, dependencies = []) {
  const [state, setState] = useState({
    data: null,
    loading: true,
    error: null,
  });

  useEffect(() => {
    const controller = new AbortController();
    let active = true;

    setState({ data: null, loading: true, error: null });

    fetcher(controller.signal)
      .then((data) => {
        if (active) setState({ data, loading: false, error: null });
      })
      .catch((error) => {
        if (!active || error?.name === "AbortError") return;
        setState({ data: null, loading: false, error });
      });

    return () => {
      active = false;
      controller.abort();
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, dependencies);

  return state;
}