import { Link } from "react-router-dom";

export default function BorderLinks({ borders = [], countries = [] }) {
  if (!borders.length) return <span className="muted">No land borders</span>;

  const lookup = new Map(countries.map((country) => [country.cca3, country]));
  return (
    <div className="border-links">
      {borders.map((code) => (
        <Link className="border-chip" key={code} to={`/country/${code}`}>
          {lookup.get(code)?.name?.common || code}
        </Link>
      ))}
    </div>
  );
}