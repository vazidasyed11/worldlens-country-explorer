export default function ErrorState({ message = "Something went wrong." }) {
  return (
    <div className="status-card error-card" role="alert">
      <div className="status-icon">!</div>
      <strong>{message}</strong>
      <span>Check your connection and refresh the page to try again.</span>
    </div>
  );
}