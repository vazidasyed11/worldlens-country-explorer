const regions = ["All regions", "Africa", "Americas", "Asia", "Europe", "Oceania", "Antarctic"];

export default function RegionFilter({ value, onChange }) {
  return (
    <label className="filter-wrap">
      <span className="sr-only">Filter by region</span>
      <select value={value} onChange={(event) => onChange(event.target.value)}>
        {regions.map((region) => (
          <option key={region} value={region === "All regions" ? "" : region}>
            {region}
          </option>
        ))}
      </select>
    </label>
  );
}