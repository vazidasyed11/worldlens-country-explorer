import { Link } from "react-router-dom";
import { useTheme } from "../context/ThemeContext";

export default function Header() {
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="site-header">
      <div className="container header-inner">
        <Link className="brand" to="/">
          <span className="brand-mark">W</span>
          <span>
            <strong>WorldLens</strong>
            <small>Country Explorer</small>
          </span>
        </Link>

        <button className="theme-toggle" onClick={toggleTheme} aria-label="Toggle color theme">
          <span aria-hidden="true">{theme === "light" ? "☾" : "☀"}</span>
          {theme === "light" ? "Dark mode" : "Light mode"}
        </button>
      </div>
    </header>
  );
}