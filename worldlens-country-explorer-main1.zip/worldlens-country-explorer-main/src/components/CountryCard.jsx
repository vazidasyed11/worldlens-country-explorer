import { Link } from "react-router-dom";

function formatPopulation(value) {
  return new Intl.NumberFormat().format(value ?? 0);
}

export default function CountryCard({ country }) {
  const languages = country.languages ? Object.values(country.languages).slice(0, 2).join(", ") : "—";

  return (
    <Link className="country-card" to={`/country/${country.cca3}`}>
      <div className="flag-frame">
        <img src={country.flags?.svg || country.flags?.png} alt={`${country.name?.common} flag`} loading="lazy" />
      </div>
      <div className="country-card-body">
        <h2>{country.name?.common}</h2>
        <dl className="mini-facts">
          <div><dt>Population:</dt><dd>{formatPopulation(country.population)}</dd></div>
          <div><dt>Region:</dt><dd>{country.region || "—"}</dd></div>
          <div><dt>Capital:</dt><dd>{country.capital?.[0] || "—"}</dd></div>
        </dl>
        <p className="language-line"><span>Languages:</span> {languages}</p>
      </div>
    </Link>
  );
}