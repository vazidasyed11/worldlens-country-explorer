export default function Loading({ message = "Loading countries..." }) {
  return (
    <div className="status-card" role="status">
      <div className="spinner" />
      <strong>{message}</strong>
      <span>Please wait a moment.</span>
    </div>
  );
}