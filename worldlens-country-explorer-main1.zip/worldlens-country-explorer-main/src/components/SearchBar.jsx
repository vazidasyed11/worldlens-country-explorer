export default function SearchBar({ value, onChange }) {
  return (
    <label className="search-wrap">
      <span className="search-icon" aria-hidden="true">⌕</span>
      <span className="sr-only">Search countries</span>
      <input
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder="Search for a country..."
        type="search"
      />
      {value && (
        <button className="clear-search" type="button" onClick={() => onChange("")} aria-label="Clear search">
          ×
        </button>
      )}
    </label>
  );
}