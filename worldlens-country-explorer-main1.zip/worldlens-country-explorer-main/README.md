# WorldLens — Country Explorer

A responsive React country explorer built from the Project 13 case study.

## Features

- Loads countries from the REST Countries API
- Search by country name
- Region filtering with `useMemo`
- Reusable `useFetch` hook with `AbortController` cleanup
- Dynamic country detail routes
- Clickable border-country navigation
- Country flag, capital, population, languages, currencies and region
- Light/dark theme using React Context
- Responsive grid and detail layout
- Loading, error and empty states

## Run locally

```bash
npm install
npm run dev
```

Then open the local Vite URL shown in the terminal.

## Build

```bash
npm run build
npm run preview
```

## API

Data is provided by REST Countries:
https://restcountries.com/

The app uses:
- `GET /v3.1/all?fields=...`
- `GET /v3.1/alpha/{code}?fields=...`
